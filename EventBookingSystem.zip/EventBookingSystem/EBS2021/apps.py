from django.apps import AppConfig


class Ebs2021Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'EBS2021'
